// 1. Object-Based
// 2. Object-Oriented Programming
// 3. Functional Programming
// 4. Event-Driven/Triggered Programming
// 5. Asynchronous Programming
// 6. Reactive Programming --> Asynchronous++
// state -> programmatically changed (js) -> View
//  /\                                         |
//   |_____________Event_______________________|