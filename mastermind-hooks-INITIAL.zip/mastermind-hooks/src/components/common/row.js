export default function Row({children}) {
    return (
        <div className="row">
            {children}
        </div>
    );
}